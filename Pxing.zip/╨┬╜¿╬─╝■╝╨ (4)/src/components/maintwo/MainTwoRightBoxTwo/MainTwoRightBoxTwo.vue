<template>
    <section class="main_two_right_box_two">
        <TwoRightBoxLeftOne v-if="reveal==1"></TwoRightBoxLeftOne>
        <TwoRightBoxLeftTwo v-else-if="reveal==2"></TwoRightBoxLeftTwo>
        <TwoRightBoxLeftThree v-else-if="reveal==3"></TwoRightBoxLeftThree>
        <TwoRightBoxLeftFour v-else-if="reveal==4"></TwoRightBoxLeftFour>
        <TwoRightBoxRightOne v-if="display==1" v-on:change="typeChange"></TwoRightBoxRightOne>
        <TwoRightBoxRightTwo v-else-if="display==2" v-on:change="typeChange"></TwoRightBoxRightTwo>
    </section>
</template>

<script>
import TwoRightBoxLeftOne from './TwoRightBoxLeft/TwoRightBoxLeftOne.vue'
import TwoRightBoxLeftTwo from './TwoRightBoxLeft/TwoRightBoxLeftTwo.vue'
import TwoRightBoxLeftThree from './TwoRightBoxLeft/TwoRightBoxLeftThree.vue'
import TwoRightBoxLeftFour from './TwoRightBoxLeft/TwoRightBoxLeftFour.vue'
import TwoRightBoxRightOne from './TwoRightBoxRight/TwoRightBoxRightOne.vue'
import TwoRightBoxRightTwo from './TwoRightBoxRight/TwoRightBoxRightTwo.vue'
    export default {
        name:"MainTwoRightBoxTwo",
        data(){
            return{
                reveal:2,
                display:2
            }
        },
        components:{
            TwoRightBoxLeftOne,
            TwoRightBoxLeftTwo,
            TwoRightBoxLeftThree,
            TwoRightBoxLeftFour,
            TwoRightBoxRightOne,
            TwoRightBoxRightTwo
        },
        methods:{
            typeChange(aaa){
                this.display = aaa
            }
        }
    }
</script>

<style lang="less" scoped>
.main_two_right_box_two{
    flex: 1;
    background-color: #fff;
    border-radius: 5px;
    display: flex;
}
.left_box{
    border-right: 1px solid #f6f6f6;
}
</style>