<template>
    <div class="main_two_right_box_two_box">
        <div class="left_box_top">
            <div class="left_box_top_div_w">
                <div class="left_box_top_div">
                    <img class="left_box_img" src="../../../../assets/img/autinfor_8.jpg" alt="">
                    <p class="left_box_top_p">
                        <span>身份证</span>
                        <span class="left_box_top_span_one">(正面)</span>
                        <span class="left_box_top_span">【认证中】</span>
                    </p>
                </div>
                <div class="left_box_top_div">
                    <img class="left_box_img" src="../../../../assets/img/autinfor_3.jpg" alt="">
                    <p class="left_box_top_p">
                        <span>身份证</span>
                        <span class="left_box_top_span_one">(反面)</span>
                        <span class="left_box_top_span">【认证中】</span>
                    </p>
                </div>
            </div>
            <p class="left_box_top_duan">请上传真实的身份证信息<span>正反面</span></p>
            <p class="left_box_top_duan">照片要四角对其，如有模糊、反光、太暗、有遮挡，则不予认证</p>
        </div>
        <div class="left_box_bottom">
            <div class="left_box_top_div left_box_bottom_div">
                <img class="left_box_img" src="../../../../assets/img/autinfor_7.jpg" alt="">
                <p class="left_box_top_p">
                    <span>资质认证</span>
                    <span class="left_box_top_span">【认证中】</span>
                </p>
            </div>
            <p class="left_box_top_duan">请上传能证明您专业技能的图片</p>
            <p class="left_box_top_duan">如:职业资格证书、加盖公章的材料证明，获奖证书等</p>
        </div>
    </div>
</template>

<script>
    export default {
        name:"TwoRightBoxLeftThree"
    }
</script>

<style lang="less" scoped>
.main_two_right_box_two_box{
    flex: 1;
    flex-direction: column;
    display: flex;
    border-right: 1px solid #f5f5f5;
}
.left_box_top_div_w{
    display: flex;
    justify-content: space-between;
}

.left_box_top,
.left_box_bottom{
    flex: 1;
    box-sizing: border-box;
    padding: 65px 55px 0px 55px;
}
.left_box_top_div{
    margin-bottom: 30px;
}
.left_box_top{
    border-bottom: 1px solid #f5f5f5;
}
.left_box_img{
    width: 220px;
    border: 2px dashed #ececec;
    margin-bottom: 20px;
    box-sizing: border-box;
}
.left_box_top_p{
    text-align: center;
    color: #7e93af;
    font-size: 16px;
}
.left_box_top_span_one{
    margin-left: 12px;
}
.left_box_top_duan{
    text-align: center;
    color: #cacaca;
    font-size: 16px;
    line-height: 28px;
}
.left_box_top_span{
    margin-left: 18px;
    color: red;
}
.left_box_bottom_div{
    margin: 0 auto;
    width: 220px;
    margin-bottom: 30px;
}
</style>