<template>
    <div class="right_two">
        <p class="right_two_p">个人简介</p>
        <p class="right_two_text_p">涂磊，1977年6月10日出生于江西省南昌市，中国内地男主持人，毕业于南方冶金学院(现江西理工大学)计算机系1996级。</p>
        <p class="right_two_text_p_two">2004年，担任长沙人民广播电台星沙之声频道(FM105)的主持人。2006年，转战电视节目，随后主持了长沙晚间法律节目
            《方圆调查》。2010年， 担任青海卫视新闻脱口秀节目《嘎嘣爆米花》的嘎嘣观察员[1]。2011年， 主持浙江钱江频道
            电视新闻时评类节目《九点半》[2]。2012年，主持了江西卫视新闻评论类节目《深度观察》[3],2013年，担任河北卫视
            情感谈话节目《情感大裁判》的主持人[4]。2014年，担任天津卫视职场招聘节目《非你莫属》的主持人[5] ;同年，在天
            津卫视情感综艺类节目《爱情保卫战》中担任情感导师[6]
        </p>
        <div class="right_two_redact" @click="change">
            <i class="fa fa-pencil fa-lg"></i>
            <span>编辑</span>
        </div>
    </div>
</template>

<script>
    export default {
        name:"TwoRightBoxRightTwo",
        methods:{
            change(){
                this.$emit("change",1)
            }
        }
    }
</script>

<style lang="less" scoped>

.right_two{
    flex-direction: column;
    padding: 65px 60px 0 45px;
    box-sizing: border-box;
    position: relative;
    width: 590px;
}
.right_two_p{
    font-size: 18px;
    margin-bottom: 38px;
}
.right_two_text_p,
.right_two_text_p_two{
    color: #686868;
    font-size: 16px;
    line-height: 28px;
}
.right_two_redact{
    position: absolute;
    right: 70px;
    top: 65px;
    font-size: 16px;
    color: #00aaff;
    cursor: pointer;
}
</style>