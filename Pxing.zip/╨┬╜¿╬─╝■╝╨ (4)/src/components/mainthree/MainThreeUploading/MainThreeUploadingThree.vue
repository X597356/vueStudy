<template>
    <section class="uploading loading_three">
        <div class="loading_two_top loading_three_top">
            <p class="loading_two_top_pone">全民股东_ 201610241223.mp4</p>
            <p class="blue_bar"><span class="blue_bar_tiao"></span><i class="fa fa-lg fa-check-circle"></i></p>
            <span>上传成功100%</span>
            <span class="loading_again">重新上传</span>
        </div>
        <div class="loading_three_bottom">
            <form action="">
                <ul>
                    <li class="loading_three_bottom_list">
                        <label for="" class="loading_three_bottom_label">标题</label>
                        <input class="loading_three_bottom_input" type="text" placeholder="请输入课程标题">
                    </li>
                    <li class="loading_three_bottom_list">
                        <label for="" class="loading_three_bottom_label">分类</label>
                        <input class="loading_three_bottom_input" type="text" placeholder="请选择课程分类">
                        <i class="fa fa-chevron-down fa-lg bottom_list_icon"></i>
                    </li>
                    <li class="loading_three_bottom_list">
                        <label for="" class="loading_three_bottom_label label_three">课程介绍</label>
                        <textarea class="loading_three_bottom_text" placeholder="请输入课程介绍"></textarea>
                    </li>
                </ul>
                <input type="submit" class="save_btn" @click="change" value="保存信息">
            </form>
        </div>
    </section>
</template>

<script>
    export default {
        name:"MainThreeUploadingThree",
        methods:{
            change(){
                this.$emit("uploadingChange",2)
            }
        }
    }
</script>

<style lang="less" scoped>
.loading_two_top{
    padding: 56px 45px 60px 50px;
    box-sizing: border-box;
    border-bottom: 2px solid #f9f9f9;
    background-color: #fafeff;
}
.loading_two_top_pone{
    margin-bottom: 16px;
}
.blue_bar{
    color:#00aaff;
    margin-bottom: 18px;
}
.blue_bar_tiao{
    display: inline-block;
    width: 1055px;
    height: 10px;
    background-color: #00aaff;
    border-radius: 10px;
    margin-right: 12px  ;
}
.loading_three_top{
    position: relative;
}
.loading_again{
    position: absolute;
    right: 65px;
    bottom: 30px;
    font-size: 16px;
    color: #00aaff;
}
.loading_three_bottom{
    padding-top: 45px;
    padding-left: 48px;
}
.bottom_list_icon{
    position: absolute;
    color: #aab5c0;
    right: 78px;
    top: 23px;
    cursor: pointer;
}
.loading_three_bottom_list{
    margin-bottom: 20px;
    position: relative;
}
.loading_three_bottom_list:last-child{
    margin-bottom: 24px;
}
.loading_three_bottom_label{
    display: inline-block;
    width: 85px;
    text-align: right;
    font-size: 16px;
    margin-right: 20px;
    color: #989898;
}
.label_three{
    padding-top: 18px;
}
.loading_three_bottom_input{
    width: 975px;
    outline: none;
    border: 0;
    line-height: 55px;
    border: 1px solid #e5e5e5;
    border-radius: 5px;
    font-size: 16px;
    text-indent: 1em;
    
}
.loading_three_bottom_input::placeholder{
    color: #afafaf;
}
.loading_three_bottom_text::placeholder{
    color: #afafaf;
}
.loading_three_bottom_text{
    width: 975px;
    outline: none;
    height: 225px;
    border: 0;
    border: 1px solid #e5e5e5;
    border-radius: 5px;
    font-size: 16px;
    text-indent: 1em;
    vertical-align: top;
    padding-top: 18px;
    box-sizing: border-box;
    resize:none
}
.save_btn{
    display: block;
    width: 210px;
    line-height: 60px;
    border: 0;
    background-color:#00aaff;
    border-radius: 5px;
    color: #fff;
    cursor: pointer;
    margin-left: 153px;
    font-size: 16px;
}
</style>