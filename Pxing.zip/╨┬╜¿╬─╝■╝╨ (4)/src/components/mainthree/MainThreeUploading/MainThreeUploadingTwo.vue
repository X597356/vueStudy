<template>
    <section class="uploading loading_two">
        <div class="loading_two_top">
            <p class="loading_two_top_pone">全民股东_ 201610241223.mp4</p>
            <p class="blue_bar"><span class="blue_bar_tiao"></span><i class="fa fa-lg fa-check-circle"></i></p>
            <span>上传成功100%</span>
        </div>
        <div class="loading_two_bottom">
            <div class="loading_two_bottom_div">
                <img class="loading_two_bottom_div_img" src="../../../assets/img/dui_right.jpg" alt="">
                <p class="loading_two_bottom_state">保存成功，等待审核</p>
                <p class="loading_two_bottom_reg">课程上传成功，正在进行人工审核，我们会在24小时后告知您审核结果，请耐心等候。</p>
                <button class="loading_two_bottom_btn" @click="change">继续上传</button>
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        name:"MainThreeUploadingTwo",
        methods:{
            change(){
                this.$emit("uploadingChange",4)
            }
        }
    }
</script>

<style lang="less" scoped>
.loading_two_top{
    padding: 56px 45px 60px 50px;
    box-sizing: border-box;
    border-bottom: 2px solid #f9f9f9;
    background-color: #fafeff;
}
.loading_two_top_pone{
    margin-bottom: 16px;
}
.blue_bar{
    color:#00aaff;
    margin-bottom: 18px;
}
.blue_bar_tiao{
    display: inline-block;
    width: 1055px;
    height: 10px;
    background-color: #00aaff;
    border-radius: 10px;
    margin-right: 12px  ;
}
.loading_two_bottom{
    padding-top: 100px;
    box-sizing: border-box;
}
.loading_two_bottom_div{
    width: 425px;
    margin: 0 auto;
    text-align: center;
    
}
.loading_two_bottom_div_img{
    margin-bottom: 30px;
}
.loading_two_bottom_state{
    font-size: 20px;
    margin-bottom: 16px;
}
.loading_two_bottom_reg{
    font-size: 16px;
    color: #888888;
    line-height: 24px;
    margin-bottom: 30px;
}
.loading_two_bottom_btn{
    outline:none;
    width: 210px;
    line-height: 60px;
    background-color: #00aaff;
    color: #fff;
    border: 0;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
}
</style>