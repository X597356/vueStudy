<template>
    <main class="main main_two wrapper">
        <MainThreeLeft></MainThreeLeft>
        <MainThreeUploadingOne v-if="display==1" @uploadingChange="uploadingType"></MainThreeUploadingOne>
        <MainThreeUploadingTwo v-else-if="display==2" @uploadingChange="uploadingType"></MainThreeUploadingTwo>
        <MainThreeUploadingThree v-else-if="display==3" @uploadingChange="uploadingType"></MainThreeUploadingThree>
        <MainThreeRight v-else-if="display==4" @uploadingChange="uploadingType"></MainThreeRight>
    </main>
</template>

<script>
import MainThreeLeft from "./MainThreeLeft"
import MainThreeRight from "./MainThreeRight"
import MainThreeUploadingOne from "./MainThreeUploading/MainThreeUploadingOne.vue"
import MainThreeUploadingTwo from "./MainThreeUploading/MainThreeUploadingTwo.vue"
import MainThreeUploadingThree from "./MainThreeUploading/MainThreeUploadingThree.vue"
export default {
    name:"MainThree",
    data(){
        return{
            display:4
        }
    },
    components:{
        MainThreeLeft,
        MainThreeRight,
        MainThreeUploadingOne,
        MainThreeUploadingTwo,
        MainThreeUploadingThree
    },
    methods:{
        uploadingType(aaa){
            this.display=aaa
        }
    }
}
</script>

<style>
.main{
    padding: 40px 0;
    display: flex;
    justify-content: space-between;
}
.uploading{
    flex: 1;
    background-color: #fff;
    border-radius: 5px;
}
</style>