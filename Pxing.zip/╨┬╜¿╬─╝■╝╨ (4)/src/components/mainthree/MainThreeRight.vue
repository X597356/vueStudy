<template>
  <section class="main_three_right">
      <div class="main_two_right_one">
          <form action="">
              <ul class="clearfix">
                  <li class="three_list" v-for="(item,index) in list" :key="index" @click="change(index,item.route)">
                      <div class="three_list_circle" :class="{actives:index==activeClass}"><i class="fa fa-check fa-lg three_list_icon active"></i></div>
                      <span class="label">{{item.text}}</span>
                  </li>
              </ul>
          </form>
      </div>
      <router-view></router-view>
  </section>
</template>

<script>
import MainThreeRightOneBox from './MainThreeRightOneBox.vue'

export default {
    name:"MainThreeRight",
    data(){
        return{
            activeClass:0,
            list:[
                {
                    route:"/threefirst",
                    text:"已发布课程"
                },
                {
                    route:"/threesecond",
                    text:"审核中课程"
                },
                {
                    route:"/threelast",
                    text:"未通过审核课程"
                },
            ]
      }
    },
    components:{
        MainThreeRightOneBox
    },
    methods:{
        change(index,aaa){
            this.activeClass=index
            this.$router.push({path:aaa})
        },
        // changes(){
        //     this.$router.push({path:"threesecond"})
        // },
        // changess(){
        //     this.$router.push({path:"threelast"})
        // },
    }
}
</script>

<style>
.three_list{
    float: left;
}
.main_three_right{
    flex: 1;
    border-radius: 5px;
    background-color: #fff;
    color: #666666;
    padding: 50px 0 103px 0;
}
.main_two_right_one{
    border-bottom: 1px solid #efefef;
    padding-bottom: 50px;
    padding-left: 40px;
    position: relative;
}
.radio{
    vertical-align: inherit;
}
.label{
    display: inline-block;
    margin-left: 18px;
    margin-right: 60px;
    font-size: 18px;
    color: black;
}
.three_list_circle{
    width: 34px;
    height: 34px;
    border: 1px solid #c9c9c9;
    border-radius: 50%;
    display: inline-block;
    vertical-align: middle;
    
    text-align: center;
    box-sizing: border-box;
}
.actives{
    background-color: #00aaff;
    border: 0;
}
.three_list_circle .three_list_icon{
    line-height: 35px;
    color: #fff;
}

/* input[type = 'radio'] {
    width: 20px;
    height: 20px;
    opacity: 0;
}
label{
    position: absolute;
    left: 5px;
    top: 3px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 1px solid #999;
}
input:checked+label {
    background-color: #3c86f1;
    border: 1px solid #3c86f1;
}
input:checked+label:after{
    position: absolute;
    content: '';
    width: 5px;
    height: 10px;
    top: 3px;
    left: 6px;
    border: 2px solid #fff;
    border-top: none;
    border-left: none;
    transform: rotate(45deg);
} */
</style>