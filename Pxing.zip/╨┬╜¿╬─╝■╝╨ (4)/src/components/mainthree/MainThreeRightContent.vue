<template>
  <div class="main_two_right_two" :class="datas.border">
        <a href="javascript:;"><img class="main_two_right_two_img" :src="datas.img" alt=""></a>
        <div>
            <p class="main_two_right_two_tr one_tr">
                <a href="javascript:;"><span>{{ datas.title }}</span></a>
                <span :class="datas.classblue">「{{ datas.time }}」</span>
            </p>
            <p class="main_two_right_two_tr two_tr">
                <span>上传时间：3月23日 15 : 43</span>
            </p>
            <p class="main_two_right_two_tr three_tr">
                <i class="fa three_tr_icon fa-user"></i>
                <span class="three_tr_student">128位学员</span>
                <i class="three_tr_icon fa fa-comments "></i>
                <span>18条评论</span>
            </p>
            <a href="javascript:;"><span class="three_tr_span">{{datas.much}}</span></a>
        </div>
    </div>
</template>

<script>

export default {
    props:['datas'],
    name:"MainThreeRightContent",
}
</script>

<style>

</style>