<template>
    <section class="main_four_right main_three_right">
      <div class="main_two_right_one main_four_right_one">
          <form action="">
              <ul class="clearfix">
                  <li class="three_list" v-for="(item,index) in lists" :key="index" @click="change(index)">
                      <div class="three_list_circle" :class="{actives:index==activeClass}"><i class="fa fa-check fa-lg three_list_icon active"></i></div>
                      <span class="label">{{item.text}}</span>
                  </li>
              </ul>
          </form>
          <span class="main_four_right_span">我要提问</span>
      </div>
      <ul>
          <li class="main_four_right_list" v-for="( item , index) in list" :key="index">
              <p class="main_four_right_list_p_one">{{ item.title }}</p>
              <div class="four_right_two">
                  <p>
                      <span class="four_right_two_cpu">CPU</span>
                      <span>AMD<i class="kongs"></i>Athlon<i class="kongs"></i>ll<i class="kongs"></i>X4<i class="kong"></i>(速龙II四核)</span>
                      <span class="four_right_two_cpu_box">640盒装CPU</span>
                      <span class="four_right_two_na">(Socket AM3/3GHz/2M二级缓存/45纳米)</span>
                      <span>主板华硕(ASUS)M5A88-...</span>
                  </p>
              </div>
              <p class="main_four_right_list_p_two">
                  <span>回答时间：</span><span>{{ item.time }}</span>
                  <span class="main_four_right_list_p_two_span_one">回答：{{ item.num }}</span> 丨
                  <span>{{ item.people }}人看过</span>
                  <span class="right_two_span">提问者：{{ item.name }}</span>
              </p>
              <span class="four_right_two_buttom" :class="item.bor_bgc">{{ item.text }}</span>
              <span class="sanjiao"></span>
          </li>
      </ul>
  </section>
</template>

<script>
    export default {
        name:"MainFourRightTwo",
        data(){
            return {
                list:[
                    {
                        title:"中午在凡客打客服电话退货了，下午可以到么？我在北京",
                        time:"3月23日 15:43",
                        num:0,
                        people:91,
                        text:"有追问",
                        bor_bgc:"one_buttom",
                        name:"流浪猫"
                    },
                    {
                        title:"中午在凡客打客服电话退货了，下午可以到么？我在北京",
                        time:"3月23日 15:43",
                        num:0,
                        people:91,
                        text:"删除回答",
                        bor_bgc:"two_buttom",
                        name:"流浪猫"
                    }
                ],
                activeClass:0,
                lists:[
                    {
                        text:"全部"
                    },
                    {
                        text:"待处理"
                    }
                ]
            }
        },
        methods:{
            change(index){
                this.activeClass=index
            }
        }
    }
</script>

<style>
.right_two_span{
    margin-left: 60px;
}
.four_right_two{
    width: 830px;
    box-sizing: border-box;
    color: #909090;
    background-color: #f8f8f8;
    padding: 20px 35px 20px 26px;
    font-size: 16px;
    margin-bottom: 25px;
    border-radius: 5px;
}
.four_right_two_cpu{
    margin-right: 32px;
}
.four_right_two_cpu_box{
    margin: 0 12px;
}
.kong{
    padding: 0 5px;
}
.four_right_two_na{
    margin-right: 20px;
}
.kongs{
    padding: 0 5px;
}
.four_right_two_buttom{
    display: block;
    position: absolute;
    right: 55px;
    top: 65px;
    width: 200px;
    box-sizing: border-box;
    text-align: center;
    padding: 0 60px;
    line-height: 42px;
    border-radius: 30px;
    font-size: 14px;
    /* transform: translate(0 ,-50%); */
    cursor: pointer;
}
.sanjiao{
    position: absolute;
    left: 62px;
    top: 75px;
    width: 0px;
    height: 0px;
    border-width: 10px;
    border-style: solid;
    border-color: transparent transparent #f8f8f8 transparent;
}
</style>