<template>
  <section class="main_right">
    <div class="main_right_top">
      <div class="main_right_top_left main_right_top_div">
        <p class="main_right_top_title">我上传的课程</p>
        <p class="main_right_top_num">
          3
          <span class="main_right_top_text">个</span>
        </p>
        <p class="main_right_top_details">
          <a href="javascript:;">
            <span>查看详情</span>
            <i class="fa fa-angle-right fa-lg main_right_top_details_icon"></i>
          </a>
        </p>
      </div>
      <div class="main_right_top_left main_right_top_div">
        <p class="main_right_top_title">我的问答</p>
        <p class="main_right_top_num">
          3
          <span class="main_right_top_text">个</span>
        </p>
        <p class="main_right_top_details">
          <a href="javascript:;">
            <span>查看详情</span>
            <i class="fa fa-angle-right fa-lg main_right_top_details_icon"></i>
          </a>
        </p>
      </div>
    </div>
    <div class="main_right_bottom">
      <p class="main_right_bottom_text clearfix">
        <span>最新学员</span>
        <span class="main_right_bottom_right">一周内新增25位学员</span>
      </p>
      <ul class="main_right_bottom_box">
        <li class="main_right_bottom_list" v-for="(item,index) in lecturer" :key="index">
          <a href="javascript:;">
            <img class="main_right_bottom_list_tx" :src="item.img" alt />
          </a>
          <p class="main_right_bottom_list_name">
            <a href="javascript:;">{{ item.name }}</a>
          </p>
        </li>
      </ul>
    </div>
  </section>
</template>

<script>
export default {
  name: "MainOneRight",
  data() {
        return {
        lecturer: [
            {
            img: require("../../assets/img/tx_2.jpg"),
            name: "杨志"
            },
            {
            img: require("../../assets/img/tx_3.jpg"),
            name: "杨静静"
            },
            {
            img: require("../../assets/img/tx_4.jpg"),
            name: "吕子秋"
            },
            {
            img: require("../../assets/img/tx_1.jpg"),
            name: "阎强"
            },
            {
            img: require("../../assets/img/tx_5.jpg"),
            name: "郭小宜"
            }
        ]
    };
  }
};
</script>

<style>
/* 中间区域右半边 */
.main_right {
  flex: 1;
  border-radius: 5px;
  display: flex;
  flex-direction: column;
}
/* 右半边上半部分 */
.main_right_top {
  display: flex;
  justify-content: space-between;
  margin-bottom: 25px;
}
.main_right_top_div {
  width: 470px;
  height: 350px;
  border-radius: 5px;
  padding-top: 45px;
  padding-left: 45px;
  box-sizing: border-box;
}
.main_right_top_div:hover .main_right_top_details {
  color: #00aaff;
}
.main_right_top_details:hover {
  color: #00aaff;
}
.main_right_top_left {
  background: url(../../assets/img/left.jpg) no-repeat;
  background-size: cover;
}

.main_right_top_left:last-child {
  background: url(../../assets/img/right.jpg) no-repeat;
  background-size: cover;
}
.main_right_top_title {
  font-size: 18px;
  font-weight: unset;
  letter-spacing: 2px;
  margin-bottom: 40px;
}
.main_right_top_num {
  font-size: 40px;
  margin-bottom: 35px;
}
.main_right_top_text {
  font-size: 18px;
  margin-left: 5px;
}
.main_right_top_details {
  font-size: 18px;
  color: #939393;
}
.main_right_top_details .main_right_top_details_icon {
  vertical-align: -10%;
  margin-left: 8px;
}

/* 右半边下半部分 */
.main_right_bottom {
  flex: 1;
  border-radius: 5px;
  background-color: #fff;
  padding: 45px 65px 0px;
  box-sizing: border-box;
}
.main_right_bottom_text {
  font-size: 18px;
  font-weight: unset;
  letter-spacing: 2px;
  margin-bottom: 50px;
}
.main_right_bottom_right {
  float: right;
  font-size: 16px;
  letter-spacing: normal;
  color: #939393;
  margin-right: 10px;
}
.main_right_bottom_box {
  display: flex;
  justify-content: space-between;
}
.main_right_bottom_list:hover .main_right_bottom_list_name {
  color: #00aaff;
}
.main_right_bottom_list_tx {
  width: 120px;
  height: 120px;
  background-size: cover;
  border-radius: 50%;
}
.main_right_bottom_list_name {
  text-align: center;
  margin-top: 20px;
  font-size: 16px;
  color: #939393;
}
</style>