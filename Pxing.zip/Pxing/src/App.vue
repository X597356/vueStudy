<template>
  <div id="app">
    <Header></Header>
    <Footer></Footer>
  </div>
</template>


<script>
import Header from "./components/Header/Header"
import Footer from "./components/Footer/Footer.vue"


export default {
  components:{
    Header,
    Footer,
  }
}
</script>




<style lang="less">
/* 全站重置样式 */
*{
    margin: 0px;
    padding: 0px;
}
body{
    font-family: 'Miocrosoft Yahei';
    font-size: 14px;
    position: relative;
    background-color: #f4f4f4;
}

ul, ol, li{
    list-style: none;
}

img{
    vertical-align: middle;
}

a{
    color: inherit;
    text-decoration: none;
}

/* a:hover{
    color: #ffe300;
    background-color: #282828;
} */


/* 全站公用样式 */
/* after伪元素清除浮动 */
.clearfix{
    zoom: 1;
}
.clearfix::after{
    content: "";
    display: block;
    height: 0px;
    line-height: 0px;
    font-size: 0px;
    clear: both;
}
.wrapper {
    width: 1585px;
    margin: 0 auto;
}
#app{
    background-color: #f4f4f4;
}
</style>
