<template>
    <div>
        <div class="main_two_right_two under_review_div"  v-for="(item,index) in list"  :key="index" :class="item.border">
            <a href="javascript:;"><img class="main_two_right_two_img" :src="item.img" alt=""></a>
            <div>
                <p class="main_two_right_two_tr one_tr">
                    <a href="javascript:;"><span>{{ item.title }}</span></a>
                </p>
                <p class="main_two_right_two_tr two_tr">
                    <span>上传时间：3月23日 15 : 43</span>
                </p>
                <a href="javascript:;"><span class="three_tr_span">{{item.much}}</span></a>
            </div>
            <div class="under_review_amend">
                <span class="under_review_amend_span">修改课程</span>
            </div>
        </div>
    </div>
</template>

<script>

    export default {
        name:"MainThreeRightTwoBox",
        data() {
            return{
                list:[
                    {
                        img:require('../../assets/img/top_one.jpg'),
                        border:"border_bottom",
                        classblue:"blue",
                        title:"显露你的实力——面试",
                        time:"进行中",
                        much:"免费"
                    },
                    {
                        img:require('../../assets/img/top_two.jpg'),
                        border:null,
                        classblue:"grey",
                        title:"微信微博新媒体营销课程",
                        time:"以结束",
                        much:"￥199"
                    },
                ]
            }
        }
    }
</script>

<style>
.under_review_div{
    align-items: center;
}
.under_review_amend{
    margin-left: auto;
}
.under_review_amend_span{
    display: block;
    width: 210px;
    line-height: 42px;
    border: 1px solid #eee;
    border-radius: 42px;
    padding: 0 68px;
    box-sizing: border-box;
    color: #00aaff;
    text-align: center;
    margin-right: 58px;
}
.under_review_amend_span:hover{
    color: #fff;
    background-color: #00aaff;
}
.main_two_right_two{
    display: flex;
    padding-top: 60px;
    padding-left: 40px;
    padding-bottom: 52px;
}
.blue {
    color: #00aaff;
}
.grey {
    color: #d0d0d0;
}
.main_two_right_two_tr {
    font-size: 18px;
    color: #000;
    margin-bottom: 20px;
}
.main_two_right_two_img{
    margin-right: 30px;
   
}
.border_bottom{
    border-bottom: 1px solid #efefef;
}
.two_tr{
    color: #a5a5a5;
    font-size: 16px;
}
.three_tr{
    color: #cccccc;
    font-size: 14px;
}
.three_tr_icon{
    margin-right: 5px;
}
.three_tr_student {
    margin-right: 24px;
}
.three_tr_span{
    font-size: 18px;
    color: #00aaff;
}
</style>