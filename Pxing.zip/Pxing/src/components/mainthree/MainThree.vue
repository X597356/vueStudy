<template>
    <main class="main main_two wrapper">
        <MainThreeLeft></MainThreeLeft>
        <MainThreeRight></MainThreeRight>
    </main>
</template>

<script>
import MainThreeLeft from "./MainThreeLeft"
import MainThreeRight from "./MainThreeRight"
export default {
    name:"MainThree",
    components:{
        MainThreeLeft,
        MainThreeRight
    }
}
</script>

<style>
.main{
    padding: 40px 0;
    display: flex;
    justify-content: space-between;
}
</style>