<template>
    <div>
        <div class="main_two_right_two under_review_div"  v-for="(item,index) in list"  :key="index" :class="item.border">
            <a href="javascript:;"><img class="main_two_right_two_img" :src="item.img" alt=""></a>
            <div>
                <p class="main_two_right_two_tr one_tr">
                    <a href="javascript:;"><span>{{ item.title }}</span></a>
                </p>
                <p class="main_two_right_two_tr two_tr">
                    <span>上传时间：3月23日 15 : 43</span>
                </p>
                <a href="javascript:;"><span class="three_tr_span">{{item.much}}</span></a>
            </div>
            <div class="under_review_amend">
                <span class="under_review_amend_span">修改课程</span>
                <span class="under_review_amend_span_two">删除课程</span>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name:"MainThreeRightThreeBox",
        data() {
            return{
                list:[
                    {
                        img:require('../../assets/img/top_one.jpg'),
                        border:"border_bottom",
                        classblue:"blue",
                        title:"显露你的实力——面试",
                        much:"失败原因：内容包含反动性质，请修改"
                    },
                    {
                        img:require('../../assets/img/top_two.jpg'),
                        border:null,
                        classblue:"grey",
                        title:"微信微博新媒体营销课程",
                        much:"失败原因：内容包含反动性质，请修改"
                    },
                ]
            }
        }
    }
</script>

<style>
.under_review_amend_span_two{
    font-size: 12px;
    color: #cdcdcd;
    display: block;
    width: 210px;
    line-height: 42px;
    padding: 0 68px;
    box-sizing: border-box;
    text-align: center;
    cursor: pointer;
}
</style>