
<template>
    <section class="main_left">
        <div class="main_left_one main_left_div">
        <a href="javascript:;"><img class="main_left_one_img" src="../../assets/img/tx_1.jpg" alt=""></a>
        <div class="main_left_one_text">
            <p class="main_left_one_text_pone">
                <span class="main_left_one_text_name">罗密欧</span>
                <i class="main_left_one_text_people"></i>
            </p>
            <p class="main_left_one_text_ptwo">
                <span>信息完整度</span>
                <span class="bule_article"></span>
                <span class="bule_text">高</span>
            </p>
            <span class="main_left_one_text_span">
                <i class="fa fa-mobile fa-2x main_left_one_text_span_i main_left_one_text_span_icon"></i>
                <i class="fa fa-id-card-o fa-lg main_left_one_text_span_i"></i>
                <i class="fa fa-envelope-o fa-lg main_left_one_text_span_i"></i>
            </span>
        </div>
    </div>
    <div class="main_left_two main_left_div">
        <div class="main_left_two_left">申请提现</div>
        <div class="main_left_two_right">
            <p class="main_left_two_right_balance">账户余额</p>
            <p class="main_left_two_right_text"><span class="main_left_two_right_num">248</span><span>元</span></p>
        </div>
    </div>
    <div class="main_left_three">
        <div>
            <span class="main_left_three_img"><i class="fa fa-address-card-o fa-5x main_left_three_img_icon"></i></span>
            <p class="main_left_three_p">实名认证 <span class="main_left_three_span">【未认证】</span></p>
        </div>
        <div>
            <span class="main_left_three_img"><i class="fa fa-file-text fa-5x main_left_three_img_icon"></i></span>
            <p class="main_left_three_p">资质认证<span class="main_left_three_span">【未认证】</span></p>
        </div>
    </div>
    </section>
</template>

<script>
    export default {
        name:'MainOneLeft'
    }
</script>

<style>

.main_left{
    width: 595px;
    margin-right: 20px;
    background-color: seashell;
    padding-top: 40px;
    background-color: #fff;
    border-radius: 5px;
    padding-bottom: 90px;
}

.main_left_one{
    display: flex;
    padding-bottom: 38px;
}
.main_left_div {
    border-bottom: 1px solid #f9f9f9;
}
.main_left_one_img{
    width: 120px;
    height: 120px;
    background-size: cover;
    border-radius: 50%;
    margin: 0 40px 0 45px;
}
.main_left_one_text{
    flex: 1;
}
.main_left_one_text_pone{
    margin-bottom: 24px;
}
.main_left_one_text_people{
    display: inline-block;
    width: 23px;
    height: 28px;
    background-image: url(../../assets/img/people.jpg);
    background-size: cover;
    vertical-align: bottom;
    margin-left: 15px;
}
.main_left_one_text_name{
    font-size: 18px;
    font-weight: unset;
    letter-spacing: 2px;
}
.main_left_one_text_ptwo{
    font-size: 16px;
    margin-bottom: 15px;
}
.bule_article{
    display: inline-block;
    width: 185px;
    height: 10px;
    background-color: #00aaff;
    border-radius: 10px;
    margin:0 10px;
}
.bule_text{
    color: #00aaff;
}
.main_left_one_text_span_icon{
    vertical-align: middle;
}
.main_left_one_text_span_i{
    margin-right: 10px;
    cursor: pointer;
}
.main_left_one_text_span_i:hover {
    color: #00aaff;
}
.main_left_two {
    display: flex;
    padding: 35px 0;
}
.main_left_two_left{
    padding: 10px 68px;
    background-color: #00aaff;
    border-radius: 25px;
    color: #fff;
    margin: 15px 70px 15px 45px;
}
.main_left_two_right{
    flex: 1;
}
.main_left_two_right_balance{
    font-size: 18px;
    color: #606060;
}
.main_left_two_right_num{
    font-size: 40px;
    margin-right: 5px;
}
.main_left_two_right_text{
    font-size: 18px;
}
.main_left_three{
    padding: 83px 50px 0 50px;
    display: flex;
    justify-content: space-between;
}
.main_left_three_img{
    display: block;
    width: 225px;
    height: 160px;
    border: 2px dashed #efefef;
    text-align: center;
    cursor: pointer;
    background-color: #f8f8f8;
}
.main_left_three_img_icon{
    margin-top: 35%;
    transform: translate(0,-50%);
    color: #00aaff;
}
.main_left_three_p{
    font-size: 16px;
    color: #8397b2;
    text-align: center;
    margin-top: 20px;
}
.main_left_three_span{
    color: #d74113;
}
</style>
