<template>
    <nav>
        <img src="require('../../assets/img/logo_two.jpg')" alt="">
        <div></div>
    </nav>
</template>

<script>
var img = require('../../assets/img/logo_two.jpg')
    export default {
        name:"LoginHeader"
    }
</script>

<style lang="scss" scoped>

</style>