<template>
    <header class="header">
        <HeaderTop></HeaderTop>
        <HeaderBottom></HeaderBottom>
    </header>
  
</template>

<script>
import HeaderTop from "./HeaderTop";
import HeaderBottom from "./HeaderBottom";
export default {
    name:"Header",
    components:{
        HeaderTop,
        HeaderBottom
    }
}
</script>

<style>
.header{
    width: 1900px;
    background-color: #fff;
    box-shadow: 0 1px 5px rgba(0, 0, 0, .1);
}
</style>