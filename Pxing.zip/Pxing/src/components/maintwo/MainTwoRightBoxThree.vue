<template>
    <div>
        this is MainTwoRightBoxThree
    </div>
</template>

<script>
    export default {
        name:"MainTwoRightBoxThree"
    }
</script>

<style lang="scss" scoped>

</style>