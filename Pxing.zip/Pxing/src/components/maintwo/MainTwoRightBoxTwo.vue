<template>
    <div>
        this is MainTwoRightBoxTwo
    </div>
</template>

<script>
    export default {
        name:"MainTwoRightBoxTwo"
    }
</script>

<style lang="scss" scoped>

</style>