<template>
  <section class="main_two_right main_two_ringht_er">
    <form>
      <ul>
        <li class="main_two_right_div">
          <label class="main_two_right_text" for="one">姓名</label>
          <input class="main_two_right_p_input" type="text" id="one" v-model="medolDatas.name" />
        </li>
        <li class="main_two_right_div">
          <label class="main_two_right_text" for="two">出生日期</label>
          <input
            class="main_two_right_p_input"
            disabled
            id="two"
            type="text"
            placeholder="本项不可输入，填写完身份证信息后自动同步出生日期"
          />
        </li>
        <li class="main_two_right_div">
          <label class="main_two_right_text" for="three">性别</label>
          <div class="main_two_right_p_div">
            <input class="main_two_right_p_input" id="three" type="text" placeholder="男" />
            <i class="fa fa-angle-down fa-lg main_two_right_p_div_icon"></i>
          </div>
        </li>
        <li class="main_two_right_div">
          <label class="main_two_right_text" for="four">手机号</label>
          <div class="main_two_right_p_div main_two_right_p_div_num">
            <input
              class="main_two_right_p_input main_two_right_p_input_num"
              id="four"
              type="text"
              v-model="medolDatas.cellPhone"
            />
            <span class="main_two_right_p_num main_two_right_p_num_two">
              <i class="fa fa-check main_two_right_p_num_icon"></i>已验证
            </span>
            <div class="main_two_right_p_input_num_text">获取验证码</div>
          </div>
        </li>
        <li class="main_two_right_div">
          <label class="main_two_right_text" for="five">邮箱</label>
          <input class="main_two_right_p_input" id="five" type="text" v-model="medolDatas.email" />
        </li>
        <li class="main_two_right_div">
          <label class="main_two_right_text" for="six">身份证</label>
          <input class="main_two_right_p_input" id="six" type="text" v-model="medolDatas.idCard" />
        </li>
        <li class="main_two_right_div">
          <label class="main_two_right_text" for="seven">微信号</label>
          <input class="main_two_right_p_input" id="seven" type="text" v-model="medolDatas.weixin" />
        </li>
        <li class="main_two_right_div">
          <label class="main_two_right_text" for="eight">QQ号</label>
          <input class="main_two_right_p_input" id="eight" type="text" v-model="medolDatas.QQ" />
        </li>
      </ul>
    </form>
    <div class="main_two_right_div_end">
      <span class="main_two_right_div_end_button button_left" v-on:click="storage">保存信息</span>
      <span class="main_two_right_div_end_button button_right" v-on:click="changes">取消修改</span>
    </div>
  </section>
</template>

<script>
export default {
  name: "MainTwoRightTwo",
  data() {
    return {
      medolDatas: this.$parent.datas,
      bbb: false
    };
  },
  methods: {
    storage() {
      this.$emit("movechanges", this.bbb, this.medolDatas);
    },
    changes() {
      this.$emit("movechanges", this.bbb);
    }
  }
};
</script>

<style>


/* 第二块中间部分右半边第二版 */
.main_two_right_div{
    margin-bottom: 20px;
    font-size: 16px;
}
.main_two_right_p_input{
    width: 530px;
    line-height: 60px;
    border-radius: 5px;
    outline:none;
    border: 1px solid #e3e3e3;
    font-size: 16px;
    text-indent: 1em;
    background-color: #fff;
    letter-spacing: 1px;
    box-sizing: border-box;
    font-family: 'Miocrosoft Yahei';
}

.main_two_right_p_div_num{
    width: 530px;
    position: relative;
    font-size: 0;
}
.main_two_right_p_input_num{
    width: 315px;
    border-top-right-radius: 0px;
    border-bottom-right-radius: 0px;
}
.main_two_right_p_num_two{
    position: absolute;
    top: 20px;
    right: 230px;
    font-size: 16px;
}
.main_two_right_p_input_num_text{
    display: inline-block;
    width: 212px;
    line-height: 60px;
    border: 1px solid #e3e3e3;
    border-bottom-right-radius: 5px;
    border-top-right-radius: 5px;
    font-size: 16px;
    vertical-align: top;
    border-left: 0;
    text-align: center;
    color: black;
    cursor: pointer;
}
.main_two_right_p_input_num_text:hover {
    color: #fff;
    background-color: #00aaff;

}
.main_two_right_p_div{
    display: inline-block;
    position: relative;
}
.main_two_right_p_div_icon{
    position: absolute;
    right: 20px;
    top: 25px;
}
.main_two_right_div_end{
    padding-left: 125px;
}
.main_two_right_div_end_button{
    display: inline-block;
    padding: 20px 60px;
    border-radius: 5px;
    background-color: #00aaff;
    color: #fff;
    text-align: center;
    margin-right: 25px;
    font-size: 16px;
    margin-bottom: 55px;
    cursor: pointer;
}
</style>