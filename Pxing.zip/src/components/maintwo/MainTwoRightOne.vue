<template>
  <section class="main_two_right main_two_ringht_one">
    <ul>
      <li class="main_two_right_p">
        <span class="main_two_right_text">姓名</span>
        <span class="main_two_right_relative">{{ medolDatas.name }}</span>
      </li>
      <span class="main_two_right_p_one" v-on:click="changes">
        <a href="javascript:;">
          <i class="fa fa-pencil fa-lg main_two_right_p_one_icon"></i> 编辑
        </a>
      </span>
      <li class="main_two_right_p">
        <span class="main_two_right_text">出生日期</span>
        <span class="main_two_right_relative">1990年3月2日</span>
      </li>
      <li class="main_two_right_p">
        <span class="main_two_right_text">性别</span>
        <span class="main_two_right_relative">男</span>
      </li>
      <li class="main_two_right_p">
        <span class="main_two_right_text">手机号</span>
        <span class="main_two_right_relative">{{ medolDatas.cellPhone }}</span>
        <span class="main_two_right_p_num">
          <i class="fa fa-check main_two_right_p_num_icon"></i>已验证
        </span>
      </li>
      <li class="main_two_right_p">
        <span class="main_two_right_text">邮箱</span>
        <span class="main_two_right_relative" v-cloak>{{ medolDatas.email }}</span>
      </li>
      <li class="main_two_right_p">
        <span class="main_two_right_text">身份证</span>
        <span class="main_two_right_relative" v-cloak>{{ medolDatas.idCard }}</span>
      </li>
      <li class="main_two_right_p">
        <span class="main_two_right_text">微信号</span>
        <span class="main_two_right_relative" v-cloak>{{ medolDatas.weixin }}</span>
      </li>
      <li class="main_two_right_p">
        <span class="main_two_right_text">QQ号</span>
        <span class="main_two_right_relative" v-cloak>{{ medolDatas.QQ }}</span>
      </li>
    </ul>
  </section>
</template>

<script>
export default {
  name: "MainTwoRightOne",
  data() {
    return {
      medolDatas: this.$parent.datas,
      aaa: false
    };
  },
  methods: {
    changes() {
      let that = this;
      this.$emit("movechange", that.aaa);
    }
  }
};
</script>

<style>
.main_two_right {
    flex:1;
    padding: 65px 60px 0 45px;
    border-radius: 5px;
    background-color: #fff;
    color: #666666;
    padding-bottom: 0;
}
.main_two_ringht_one{
    position: relative;
    padding-bottom: 116px;
}
.main_two_right_p{
    margin-bottom: 20px;
    font-size: 16px;
    /* line-height: 60px; */
}
.main_two_right_text{
    display: inline-block;
    width: 75px;
    text-align: right;
    margin-right: 45px;
}
.main_two_right_relative{
    color: black;
    padding-left: 1em;
    display: inline-block;
    line-height: 60px;
    border: 1px solid transparent;
    box-sizing: border-box;
    letter-spacing: 1px;
}
.main_two_right_p_one{
    position: absolute;
    color: #00aaff;
    top: 60px;
    right: 60px;
}
.main_two_right_p_one_icon{
    vertical-align: text-top;
}
.main_two_right_p_num{
    color: #95c300;
}
.main_two_right_p_num_icon{
    margin: 0 10px 0 30px;
}


</style>