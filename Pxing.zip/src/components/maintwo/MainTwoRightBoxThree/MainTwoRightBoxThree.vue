<template>
    <section class="main_three_right">
        <p class="main_three_right_p">登录密码</p>
        <div class="main_three_right_box">
            <form action="">
                <ul>
                    <li class="three_right_list">
                        <label class="three_right_label" for="">原密码</label>
                        <input class="three_right_input" type="text" placeholder="请输入原始密码">
                    </li>
                    <li class="three_right_list">
                        <label class="three_right_label" for="">新密码</label>
                        <input class="three_right_input" type="text" placeholder="请输入新密码">
                    </li>
                    <li class="three_right_list">
                        <label class="three_right_label" for="">确认密码</label>
                        <input class="three_right_input" type="text" placeholder="请在此输入新密码">
                    </li>
                </ul>
                <div class="three_right_btn">
                    <input type="submit" class="three_right_btn_sure" value="确认修改">
                    <input type="submit" class="three_right_btn_cancle" value="取消修改">
                </div>
            </form>
        </div>
    </section>
</template>

<script>
    export default {
        name:"MainTwoRightBoxThree"
    }
</script>

<style lang="less" scoped>
.main_three_right{
    flex: 1;
    border-radius: 5px;
    background-color: #fff;
}
.main_three_right_p{
    padding-left: 60px;
    font-size: 18px;
    margin-bottom: 60px;
}
.main_three_right_box{
    border-top: 1px solid #ececec;
    padding: 60px 0 0 60px;
    box-sizing: border-box; 
}
.three_right_input{
    line-height: 60px;
    font-size: 16px;
    width: 530px;
    border: 0;
    outline: none;
    text-indent: 1em;
    border-radius: 5px;
    border: 1px solid #dfdfdf;
}
.three_right_input::placeholder{
    color: #d0d0d0;
}
.three_right_list{
    margin-bottom: 20px;
}
.three_right_list:last-child{
    margin-bottom: 30px;
}
.three_right_label{
    display: inline-block;
    width: 80px;
    text-align: right;
    font-size: 16px;
    margin-right: 24px;
}
.three_right_btn{
    padding-left: 104px;
}
.three_right_btn_sure,
.three_right_btn_cancle {
    width: 210px;
    line-height: 60px;
    font-size: 18px;
    outline: none;
    border: 1px solid #dfdfdf;
    border-radius: 5px;
    background-color: #fff;
    cursor: pointer;
}
.three_right_btn_sure {
    margin-right: 25px;
    background-color: #00aaff;
    color: #fff;
}
</style>