<template>
    <main class="main main_two wrapper">
        <MainTwoLeft></MainTwoLeft>
        <MainTwoRightOne  v-on:movechange="move" v-show="one"></MainTwoRightOne>
        <MainTwoRightTwo  v-on:movechanges="moves" v-show="two"></MainTwoRightTwo>
    </main>
</template>

<script>
import MainTwoLeft from './MainTwoLeft.vue'
import MainTwoRightOne from './MainTwoRightOne.vue'
import MainTwoRightTwo from './MainTwoRightTwo.vue'

    export default {
        name:'MainTwo',
        data(){
            return{
                one:true,
                two:false,
                datas:{
                    name:"刘子熙",
                    cellPhone:1590578034,
                    email:"xuepin@admin.com",
                    idCard:110324199003024357,
                    weixin:13810194417,
                    QQ:367722645
                },
            }
        },
        components:{
            MainTwoLeft,
            MainTwoRightOne,
            MainTwoRightTwo
        },
        methods:{
            move(aaa,){
                this.one = aaa
                this.two = !aaa
                
            },
            moves(bbb,ccc){
                this.two = bbb
                this.one = !bbb
                this.datas = ccc
            }
        },
    }
</script>

<style>

</style>