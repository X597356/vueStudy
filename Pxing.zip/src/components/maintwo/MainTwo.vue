<template>
    <main class="main main_two wrapper">
        <!-- <MainTwoLeft></MainTwoLeft> -->
        <section class="main_two_left">
            <div class="main_two_left_top_box">
                <img class="main_two_left_top_box_img" src="../../assets/img/tx_1.jpg" alt="">
                <p class="main_two_left_top_box_text">编辑</p>
            </div>
            <ul class="main_two_left_bottom_box">
                <router-link :to="item.route" tag="li" class="main_two_left_bottom_box_p " v-for="(item,index) in datas" :key="index">
                    <a href="javascript:;">
                        <i class="fa fa-2x main_two_left_bottom_box_p_icon" :class='item.icon'></i>
                        <span>{{ item.text }}</span>
                    </a>
                </router-link>
            </ul>
        </section>
        <!-- <MainTwoRightBox></MainTwoRightBox> -->
        <router-view></router-view>
    </main>
</template>

<script>
// import MainTwoRightBox from './MainTwoRightBox.vue'
// import MainTwoRightOne from './MainTwoRightOne.vue'
// import MainTwoRightTwo from './MainTwoRightTwo.vue'

    export default {
        name:'MainTwo',
        data(){
            return{
                datas:[
                    {
                        route: "twofirst",
                        icon:"fa-user",
                        text:"我的信息"
                    },
                    {
                        route: "twosecond",
                        icon:"fa-check-square",
                        text:"认证信息"
                    },
                    {
                        route: "twolast",
                        icon:"fa-cog",
                        text:"密码管理"
                    }
                ]
            }
        },
        components:{
            // MainTwoRightBox
        }
    }
</script>

<style>
/* 第二块中间部分左半边 */
.main_two_left {
    width: 370px;
    min-height: 770px;
    box-sizing: border-box;
    background-color: #fff;
    color: #646464;
    border-radius: 5px;
    padding-top: 65px;
    margin-right: 25px;
}
.main_two_left_top_box{
    width: 135px;
    height: 135px;
    border-radius: 50%;
    overflow: hidden;
    position: relative;
    text-align: center;
    margin: 0 auto;
    margin-bottom: 60px;
}
.main_two_left_top_box_img{
    height: 100%;
    background-size: cover;
}
.main_two_left_top_box_text{
    position: absolute;
    width: 100%;
    bottom: 0;
    color: #fff;
    line-height: 32px;
    background-color:rgba(0, 0, 0, .3);
}
.main_two_left_bottom_box{
    width: 135px;
    margin: 0 auto;
}
/* .main_two_left_bottom_color{
    color: #00aaff;
} */
.main_two_left_bottom_box_p {
    font-size: 16px;
    margin-bottom: 40px;
}
.main_two_left_bottom_box_p:first-child{
    color: #00aaff;
}
.main_two_left_bottom_box_p:first-child .main_two_left_bottom_box_p_icon{
    margin-left: 6px;
}
.main_two_left_bottom_box_p_icon{
    margin-right: 10px;
    margin-left: 3px;
    vertical-align: sub;
}
/* .main_two_left_bottom_icon_one{
    margin-left: 6px;
} */
.main_two_left_bottom_box_p a:hover {
    color: #00aaff;
}
</style>