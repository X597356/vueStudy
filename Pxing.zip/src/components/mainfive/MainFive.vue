<template>
    <main class="main wrapper main_five">
        this is MainFive
    </main>
</template>

<script>
    export default {
        name:'MainFive'
    }
</script>

<style>
.main_five{
    min-height: 710px;
    background-color: #fff;
    margin: 40px auto;
    border-radius: 5px;
}
</style>