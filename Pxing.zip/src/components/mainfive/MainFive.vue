<template>
    <main class="main wrapper">
        this is MainFive
    </main>
</template>

<script>
    export default {
        name:'MainFive'
    }
</script>

<style lang="scss" scoped>

</style>