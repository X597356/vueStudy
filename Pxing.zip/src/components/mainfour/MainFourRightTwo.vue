<template>
    <div>
        this is MainFourRightTwo
    </div>
</template>

<script>
    export default {
        name:"MainFourRightTwo"
    }
</script>

<style>

</style>