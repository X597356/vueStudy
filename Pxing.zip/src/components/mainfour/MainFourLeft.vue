<template>
  <div>
    <section class="main_two_left">
      <div class="main_two_left_top_box">
        <img class="main_two_left_top_box_img" src="../../assets/img/tx_1.jpg" alt />
        <p class="main_two_left_top_box_text">编辑</p>
      </div>
      <ul class="main_two_left_bottom_box">
        <!-- <li
          class="main_two_left_bottom_box_p_three"
          v-for="(item,index) in datas"
          :key="index"
          v-on:click="change(index,item.first)"
          :class="{active:index==activeclass}"
        >
          <a href="javascript:;">
            <i class="fa fa-2x main_two_left_bottom_box_p_icon" :class="item.icon"></i>
            <span>{{ item.text }}</span>
          </a>
        </li> -->
        <router-link
          :to="item.first"
          tag="li"
          class="main_two_left_bottom_box_p_three"
          v-for="(item,index) in datas"
          :key="index"
          v-on:click="change(index)"
          :class="{active:index==activeClass}"
        >
            <a href="javascript:;">
                <i class="fa fa-2x main_two_left_bottom_box_p_icon" :class="item.icon"></i>
                <span>{{ item.text }}</span>
            </a>
        </router-link>
      </ul>
    </section>
  </div>
</template>

<script>
export default {
  name: "MainFourLeft",
  data() {
    return {
      activeClass: 0,
      datas: [
        {
          first: "/first",
          icon: "fa-user",
          text: "我的提问"
        },
        {
          first: "/last",
          icon: "fa-check-square",
          text: "我的回答"
        }
      ]
    };
  },
  methods: {
    change(index) {
      console.log(1111);
      this.activeClass = index;
    //   this.$router.push({ path: aaa });
    }
  }
};
</script>

<style>
.active {
  color: #00aaff;
}
</style>