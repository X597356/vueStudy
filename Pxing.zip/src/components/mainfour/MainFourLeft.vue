<template>
<div>
    <section class="main_two_left">
        <div class="main_two_left_top_box">
            <img class="main_two_left_top_box_img" src="../../assets/img/tx_1.jpg" alt="">
            <p class="main_two_left_top_box_text">编辑</p>
        </div>
        <ul class="main_two_left_bottom_box">
            <li class="main_two_left_bottom_box_p " v-for="(item,index) in datas" :key="index">
                <router-link :to="item.first">
                    <i class="fa fa-2x main_two_left_bottom_box_p_icon" :class='item.icon'></i>
                    <span>{{ item.text }}</span>
                </router-link>
            </li>
        </ul>
    </section>
</div>
</template>

<script>
    export default {
        name:"MainFourLeft",
        data(){
        return {
            datas:[
                {
                    first:"first",
                    icon:"fa-user",
                    text:"我的提问"
                },
                {
                    first:"last",
                    icon:"fa-check-square",
                    text:"我的回答"
                },
            ]
        }
    },
    }
</script>

<style>

</style>