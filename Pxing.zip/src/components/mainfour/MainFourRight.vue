<template>
    <section class="main_four_right main_three_right">
      <div class="main_two_right_one main_four_right_one">
          <form action="">
              <input type="radio" class="radio" id="one" name="nameradio" ><label class="label" for="one">全部</label>
              <input type="radio" class="radio"  id="two" name="nameradio"><label class="label" for="two">待处理</label>
          </form>
          <span class="main_four_right_span">我要提问</span>
      </div>
      <ul>
          <li class="main_four_right_list" v-for="( item , index) in list" :key="index">
              <p class="main_four_right_list_p_one">{{ item.title }}</p>
              <p class="main_four_right_list_p_two">
                  <span>提问时间：</span><span>{{ item.time }}</span>
                  <span class="main_four_right_list_p_two_span_one">回答：{{ item.num }}</span> 丨
                  <span>{{ item.people }}人看过</span>
              </p>
              <span class="main_four_right_list_buttom" :class="item.bor_bgc">{{ item.text }}</span>
          </li>
      </ul>
  </section>
</template>

<script>
    export default {
        name:"MainFourRight",
        data(){
            return {
                list:[
                    {
                        title:"中午在凡客打客服电话退货了，下午可以到么？我在北京",
                        time:"3月23日 15:43",
                        num:0,
                        people:91,
                        text:"查看并处理",
                        bor_bgc:"one_buttom"
                    },
                    {
                        title:"想买电脑 不懂配置 求各位大神给一套3000-4000的配置 急求配置 谢谢",
                        time:"3月23日 15:43",
                        num:0,
                        people:91,
                        text:"删除问题",
                        bor_bgc:"two_buttom"
                    }
                ]
            }
        }
    }
</script>

<style>
.main_four_right{
    flex: 1;
    padding-top: 50px;
    border-radius: 5px;
    min-height: 770px;
    background-color: #fff;
    box-sizing: border-box;
}
.main_four_right_span{
    position: absolute;
    display: block;
    line-height: 42px;
    background-color: #00aaff;
    color: #fff;
    right: 55px;
    padding: 0 70px;
    border-radius: 10px;
    cursor: pointer;
}
.main_four_right_one{
    display: flex;
    align-items: center;
}
.main_four_right_list{
    padding: 50px 0;
    font-size: 18px;
    padding-left: 40px;
    position: relative;
    border-bottom: 1px solid #efefef;
}
.main_four_right_list_p_one{
    margin-bottom: 20px;
}
.main_four_right_list_p_two{
    font-size: 14px;
    color: #888888;
}
.main_four_right_list_p_two_span_one{
    margin-left: 48px;
}
.main_four_right_list_buttom{
    display: block;
    position: absolute;
    right: 55px;
    top: 65px;
    width: 200px;
    box-sizing: border-box;
    text-align: center;
    padding: 0 60px;
    line-height: 42px;
    color: #00aaff;
    border-radius: 30px;
    font-size: 14px;
    /* transform: translate(0 ,-50%); */
    cursor: pointer;
}
.one_buttom {
    border: 1px solid #efefef;
    color: #00aaff;
}
.one_buttom:hover {
    background-color: #00aaff;
    color: #fff;
}
.two_buttom {
    color:#cecece;
}
</style>