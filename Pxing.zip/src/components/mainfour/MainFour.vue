<template>
  <main class="main wrapper">
    <section class="main_two_left">
      <div class="main_two_left_top_box">
        <img class="main_two_left_top_box_img" src="../../assets/img/tx_1.jpg" alt />
        <p class="main_two_left_top_box_text">编辑</p>
      </div>
      <ul class="main_two_left_bottom_box">
        <li
          class="main_two_left_bottom_box_p"
          v-for="(item,index) in datas"
          :key="index"
          @click="change(index,item.first)"
          :class="{active:index==activeClass}"
        >
            <a href="javascript:;">
            <i class="fa fa-2x main_two_left_bottom_box_p_icon" :class="item.icon"></i>
            <span>{{ item.text }}</span>
          </a>
        </li>
      </ul>
    </section>
    <router-view></router-view>
  </main>
</template>

<script>
import MainFourRight from "./MainFourRight.vue";
export default {
  name: "MainFour",
  components: {
    MainFourRight
  },
  data() {
    return {
        activeClass:0,
      datas: [
        {
          first: "/first",
          icon: "fa-user",
          text: "我的提问"
        },
        {
          first: "/last",
          icon: "fa-check-square",
          text: "我的回答"
        }
      ]
    };
  },
  methods: {
    change(index,aaa) {
      this.activeClass = index;
      this.$router.push({ path: aaa });
    }
  }
};
</script>

<style lang="less" scoped>
.active {
  color: #00aaff;
}
</style>