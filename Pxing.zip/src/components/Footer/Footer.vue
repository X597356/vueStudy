<template>
  <footer class="footer">
        <section class="wrapper">
            <p class="footer_one">中国领先大学生成长平台<i class="fa fa-copyright footer_one_icon"></i>2016 e学聘</p>
            <p class="footer_two">ICP备16500007号<i class="vertical_icon"></i><a class="footer_one_a" href="javascript:;">联系我们</a>exuepin@exuepin.com<i class="vertical_icon"></i><a class="footer_one_a" href="javascript:;">关于我们</a></p>
        </section>
    </footer>
</template>

<script>
export default {
    name:"Footer"
}
</script>

<style>
/* 底部 */
.footer{
    width: 1900px;
    background-color: #fff;
    text-align: center;
    padding: 30px 0;
    color: #939393;
}
.footer_one{
    margin-bottom: 12px;
}
.footer_one_icon{
    margin-left: 10px;
}
.footer_one_a {
    margin-right: 10px;
}
.vertical_icon {
    display: inline-block;
    border: 0.5px solid #939393;
    height: 15px;
    margin: 0px 10px;
    vertical-align: middle;
}
</style>