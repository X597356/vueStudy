<template>
    <main class="main main_one wrapper">
        <MainOneLeft></MainOneLeft>
        <MainOneRight></MainOneRight>
    </main>
</template>

<script>
import MainOneLeft from './MainOneLeft.vue';
import MainOneRight from './MainOneRight.vue'

    export default {
        name:"MainOne",
        components:{
            MainOneLeft,
            MainOneRight
        }
    }
</script>

<style>

</style>