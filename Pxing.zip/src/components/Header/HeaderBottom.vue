<template>
    <section class="nav ">
      <div class="header_two wrapper">
        <ul class="header_two_ul">
          <li
            class="header_two_list"
            v-for="(item , index) in list"
            :key="index"
            v-on:click="change(index,item.to)"
            :class="{ changes:currentIndex == index }"
          >
            <a href="javascript:;" class="header_two_list_a">{{ item.text }}</a>
          </li>
        </ul>
        <div class="header_two_course">
          <span class="header_two_course_span">
            <i class="header_two_course_span_icon">+</i>添加课程
          </span>
        </div>
      </div>
    </section>
</template>

<script>
export default {
  name: "HeaderBottom",
  data() {
    return {
      currentIndex: null,
      list: [
        {
          to: "one",
          text: "My Center"
        },
        {
          to: "two",
          text: "基本信息"
        },
        {
          to: "three",
          text: "课程管理"
        },
        {
          to: "four",
          text: "我的问答"
        },
        {
          to: "five",
          text: "我的收入"
        }
      ]
    };
  },
  methods: {
    change(index,a) {
      this.currentIndex = index;
      this.$router.push({ path:a })
    }
  }
};
</script>

<style>
.nav {
  background-color: #fff;
}
.header_two {
  display: flex;
  height: 120px;
  align-items: center;
}
.header_two_ul {
  display: flex;
  align-items: center;
  height: 80px;
}
.header_two_list {
  margin-left: 98px;
  font-size: 16px;
  color: #777676;
  border-bottom: 2px solid transparent;
  box-sizing: border-box;
}
.header_two_list:first-child {
  font-size: 30px;
  color: #00aaff;
  margin-left: 0;
  margin-right: 30px;
  border-bottom: 2px solid transparent;
}
.header_two_list:first-child a{
    padding-top: 8px;
}
.header_two_list_a {
  display: block;
  padding: 24px 0;
}
.header_two_list_a:hover {
  color: #00aaff;
}
.changes {
  border-bottom: 2px solid #00aaff;
  color: #00aaff;
}
.header_two_course {
  margin-left: auto;
}
.header_two_course_span {
  color: #00aaff;
  font-size: 18px;
  display: block;
  margin-top: 37px;
  padding: 10px 50px;
  border: 1px solid #ececec;
  border-radius: 50px;
  cursor: pointer;
  margin-bottom: 25px;
}
.header_two_course_span_icon {
  font-size: 40px;
  font-style: normal;
  vertical-align: sub;
  margin-right: 5px;
  line-height: 0;
}
</style>