<template>
  <section class="header_one">
        <div class="header_one_content wrapper">
            <a href="javascript:;" @click="tiao()"><img src="../../assets/img/logo.jpg" alt=""></a>
            <div class="header_one_content_user">
                <a href="javascript:;"><img class="header_one_content_user_img" src="../../assets/img/tx_1.jpg" alt=""></a>
                <a href="javascript:;"><span class="header_one_content_user_name">罗密欧</span></a>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name:"HeaderTop",
    methods:{
        tiao(){
            this.$router.push({ path:"Login" })
        }
    }
}
</script>

<style>
.header_one {
    background-color: #333;
}
.header_one_content{
    display: flex;
}
.header_one_content_user{
    margin-left: auto;
    position: relative;
    margin-top: 5px;
    color: #ececec;
}

.header_one_content_user_img{
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-size: cover;
    margin-right: 30px;
}

.header_one_content_user_name {
    margin-right: 65px;
}
/* 下箭头 */
.header_one_content_user::after {
    display: inline-block;
    content: " ";
    height: 8px;
    width: 8px;
    border-width: 0 2px 2px 0;
    border-color: #999999;
    border-style: solid;
    transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);
    transform-origin: center;
    transition: transform .3s;
    position: absolute;
    top: 50%;
    right: 35px;
    margin-top: -8px;
}
</style>