<template>
    <div>
        <Header></Header>
        <router-view></router-view>
        <Footer></Footer>
    </div>
</template>

<script>
import Header from "./Header/Header.vue"
import Footer from "./Footer/Footer.vue"
import MainOne from './mainone/MainOne.vue'
    export default {
        name:"Main",
        components:{
            Header,
            MainOne,
            Footer
        }
    }
</script>

<style lang="scss" scoped>

</style>