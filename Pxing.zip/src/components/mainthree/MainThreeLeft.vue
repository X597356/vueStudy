<template>
  <section class="main_two_left">
        <div class="main_two_left_top_box">
            <img class="main_two_left_top_box_img" src="../../assets/img/tx_1.jpg" alt="">
            <p class="main_two_left_top_box_text">编辑</p>
        </div>
        <ul class="main_two_left_bottom_box">
            <li class="main_two_left_bottom_box_p_three" :class="{active:activeclass==index}" @click="change(index)" v-for="(item,index) in datas" :key="index">
                <a href="javascript:;">
                    <i class="fa fa-2x main_two_left_bottom_box_p_icon" :class='item.icon'></i>
                    <span>{{ item.text }}</span>
                </a>
            </li>
        </ul>
    </section>
</template>

<script>
export default {
    data(){
        return {
            activeclass:0,
            datas:[
                {
                    icon:"fa-user",
                    text:"我的课程"
                },
                {
                    icon:"fa-check-square",
                    text:"我的活动"
                },
            ]
        }
    },
    name:"MainThreeLeft",
    methods:{
        change(index){
            this.activeclass=index
        }
    }
}
</script>

<style>
.main_two_left {
    width: 370px;
    background-color: #fff;
    color: #646464;
    border-radius: 5px;
    padding-top: 65px;
    margin-right: 25px;
}
.main_two_left_top_box{
    width: 135px;
    height: 135px;
    border-radius: 50%;
    overflow: hidden;
    position: relative;
    text-align: center;
    margin: 0 auto;
    margin-bottom: 60px;
    cursor: pointer;
}
.main_two_left_top_box_img{
    height: 100%;
    background-size: cover;
}
.main_two_left_top_box_text{
    position: absolute;
    width: 100%;
    bottom: 0;
    color: #fff;
    line-height: 32px;
    background-color:rgba(0, 0, 0, .3);
}
.main_two_left_bottom_box{
    width: 135px;
    margin: 0 auto;
}
.main_two_left_bottom_box_p_three {
    font-size: 16px;
    margin-bottom: 40px;
}
/* .main_two_left_bottom_box_p_three:first-child{
    color: #00aaff;
} */
.main_two_left_bottom_box_p_three:first-child .main_two_left_bottom_box_p_icon{
    margin-left: 6px;
}
.main_two_left_bottom_box_p_icon{
    margin-right: 10px;
    margin-left: 3px;
    vertical-align: sub;
}
.main_two_left_bottom_box_p_three a:hover {
    color: #00aaff;
}
</style>