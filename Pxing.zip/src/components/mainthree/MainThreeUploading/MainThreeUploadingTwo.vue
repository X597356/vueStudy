<template>
    <section class="uploading loading_two">

    </section>
</template>

<script>
    export default {
        name:"MainThreeUploadingTwo"
    }
</script>

<style lang="less" scoped>

</style>