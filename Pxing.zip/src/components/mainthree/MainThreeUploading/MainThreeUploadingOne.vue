<template>
    <section class="uploading loading_one">
        <img class="loading_one_img" src="../../../assets/img/video.jpg" alt="" @click="change">
        <div class="loading_one_div">
            <p>1、不得.上传未经授权的他人作品，以及色情、反动等违法视频。</p>
            <p>2、视频大小限制:不支持断点续传,视频文件最大200M</p>
            <p>3、支持视频音频格式| mp4、flv、 f4v、 webrh</p>
            <p>4、不支持时长小于1秒或大于10小时的视频文件，上传 后将不能成功转码</p>
            <p>5、高清( 360P ): 视频分辨率>=640x360， 视频码率> =800kbps</p>
            <p>6、超清( 720P ):视频分辨率>=960x540， 视频码率>=1500kbps</p>
            <p>7、蓝光(1080P) :视频分辨率>=1920x1080，视频码率>=2500kbps</p>
        </div>
        
    </section>
</template>

<script>
    export default {
        name:"MainThreeUploadingOne",
        methods:{
            change(){

                this.$emit("uploadingChange",4)
            }
        }
    }
</script>

<style lang="less" scoped>
.loading_one{
    padding-top: 140px;
    box-sizing: border-box;
}
.loading_one_img{
    display: block;
    width: 172px;
    margin: 0 auto;
    cursor: pointer;
    margin-bottom: 45px;
}
.loading_one_div {
    width: 530px;
    margin: 0 auto;
    font-size: 16px;
    color: #c6c6c6;
}
.loading_one_div p {
    margin-bottom: 30px;
}
</style>