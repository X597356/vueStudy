<template>
    <section class="uploading loading_three">

    </section>
</template>

<script>
    export default {
        name:"MainThreeUploadingThree"
    }
</script>

<style lang="less" scoped>

</style>