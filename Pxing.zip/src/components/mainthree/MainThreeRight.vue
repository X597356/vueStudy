<template>
  <section class="main_three_right">
      <div class="main_two_right_one">
          <form action="">
              <ul class="clearfix">
                  <router-link to="threefirst" tag="li" class="three_list">
                    <input type="radio" class="radio" id="one" name="nameradio" ><label class="label" for="one">已发布课程</label>
                  </router-link>
                  <router-link to="threesecond" tag="li" class="three_list">
                    <input type="radio" class="radio" id="one" name="nameradio" ><label class="label" for="one">审核中课程</label>
                  </router-link>
                  <router-link to="threelast" tag="li" class="three_list">
                    <input type="radio" class="radio" id="one" name="nameradio" ><label class="label" for="one">未通过审核课程</label>
                  </router-link>
              </ul>
          </form>
      </div>
      <router-view></router-view>
  </section>
</template>

<script>
import MainThreeRightOneBox from './MainThreeRightOneBox.vue'

export default {
    name:"MainThreeRight",
    components:{
        MainThreeRightOneBox
    },
    methods:{
        change(){
            this.$router.push({path:"threefirst"})
        },
        changes(){
            this.$router.push({path:"threesecond"})
        },
        changess(){
            this.$router.push({path:"threelast"})
        },
    }
}
</script>

<style>
.three_list{
    float: left;
}
.main_three_right{
    flex: 1;
    border-radius: 5px;
    background-color: #fff;
    color: #666666;
    padding: 50px 0 103px 0;
}
.main_two_right_one{
    border-bottom: 1px solid #efefef;
    padding-bottom: 50px;
    padding-left: 40px;
    position: relative;
}
.radio{
    vertical-align: inherit;
}
.label{
    display: inline-block;
    margin-left: 18px;
    margin-right: 60px;
    font-size: 18px;
    color: black;
}




/* input[type = 'radio'] {
    width: 20px;
    height: 20px;
    opacity: 0;
}
label{
    position: absolute;
    left: 5px;
    top: 3px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 1px solid #999;
}
input:checked+label {
    background-color: #3c86f1;
    border: 1px solid #3c86f1;
}
input:checked+label:after{
    position: absolute;
    content: '';
    width: 5px;
    height: 10px;
    top: 3px;
    left: 6px;
    border: 2px solid #fff;
    border-top: none;
    border-left: none;
    transform: rotate(45deg);
} */
</style>