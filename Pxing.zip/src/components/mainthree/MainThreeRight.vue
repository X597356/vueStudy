<template>
  <section class="main_two_right main_three_right">
      <div class="main_two_right_one">
          <form action="">
              <input type="radio" class="radio" id="one" name="nameradio" ><label class="label" for="one">已发布课程</label>
              <input type="radio" class="radio"  id="two" name="nameradio"><label class="label" for="two">审核中课程</label>
              <input type="radio"  class="radio" id="three" name="nameradio"><label class="label" for="three">未通过审核课程</label>
          </form>
      </div>
      <MainThreeRightContent v-for="(item,index) in list" :key="index" :datas="item"></MainThreeRightContent>
  </section>
</template>

<script>
import MainThreeRightContent from "./MainThreeRightContent"

export default {
    name:"MainThreeRight",
    data() {
        return{
            list:[
                {
                    img:require('../../assets/img/top_one.jpg'),
                    border:"border_bottom",
                    classblue:"blue",
                    title:"显露你的实力——面试",
                    time:"进行中",
                    much:"免费"
                },
                {
                    img:require('../../assets/img/top_two.jpg'),
                    border:null,
                    classblue:"grey",
                    title:"微信微博新媒体营销课程",
                    time:"以结束",
                    much:"￥199"
                },
            ]
        }
    },
    components:{
        MainThreeRightContent,
    }
}
</script>

<style>
.main_two_right {
    flex:1;
    padding-top: 50px;
    border-radius: 5px;
    background-color: #fff;
    color: #666666;
    
}
.main_three_right{
    padding-bottom: 110px;
}
.main_two_right_one{
    border-bottom: 1px solid #efefef;
    padding-bottom: 50px;
    padding-left: 40px;
    position: relative;
}
.radio{
    vertical-align: inherit;
}
.label{
    display: inline-block;
    margin-left: 18px;
    margin-right: 60px;
    font-size: 18px;
    color: black;
}

.main_two_right_two{
    display: flex;
    padding-top: 60px;
    padding-left: 40px;
    padding-bottom: 52px;
}
.blue {
    color: #00aaff;
}
.grey {
    color: #d0d0d0;
}
.main_two_right_two_tr {
    font-size: 18px;
    color: #000;
    margin-bottom: 20px;
}
.main_two_right_two_img{
    margin-right: 30px;
   
}
.border_bottom{
    border-bottom: 1px solid #efefef;
}
.two_tr{
    color: #a5a5a5;
    font-size: 16px;
}
.three_tr{
    color: #cccccc;
    font-size: 14px;
}
.three_tr_icon{
    margin-right: 5px;
}
.three_tr_student {
    margin-right: 24px;
}
.three_tr_span{
    font-size: 18px;
    color: #00aaff;
}


/* input[type = 'radio'] {
    width: 20px;
    height: 20px;
    opacity: 0;
}
label{
    position: absolute;
    left: 5px;
    top: 3px;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    border: 1px solid #999;
}
input:checked+label {
    background-color: #3c86f1;
    border: 1px solid #3c86f1;
}
input:checked+label:after{
    position: absolute;
    content: '';
    width: 5px;
    height: 10px;
    top: 3px;
    left: 6px;
    border: 2px solid #fff;
    border-top: none;
    border-left: none;
    transform: rotate(45deg);
} */
</style>