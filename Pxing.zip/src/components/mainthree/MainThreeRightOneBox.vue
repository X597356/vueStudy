<template>
    <div>
        <MainThreeRightContent v-for="(item,index) in list" :key="index" :datas="item"></MainThreeRightContent>
    </div>
</template>

<script>
import MainThreeRightContent from "./MainThreeRightContent"

    export default {
        name:"MainThreeRightOneBox",
        data() {
            return{
                list:[
                    {
                        img:require('../../assets/img/top_one.jpg'),
                        border:"border_bottom",
                        classblue:"blue",
                        title:"显露你的实力——面试",
                        time:"进行中",
                        much:"免费"
                    },
                    {
                        img:require('../../assets/img/top_two.jpg'),
                        border:null,
                        classblue:"grey",
                        title:"微信微博新媒体营销课程",
                        time:"以结束",
                        much:"￥199"
                    },
                ]
            }
        },
        components:{
            MainThreeRightContent,
        }
    }
</script>

<style>
.main_two_right_two{
    display: flex;
    padding-top: 60px;
    padding-left: 40px;
    padding-bottom: 52px;
}
.blue {
    color: #00aaff;
}
.grey {
    color: #d0d0d0;
}
.main_two_right_two_tr {
    font-size: 18px;
    color: #000;
    margin-bottom: 20px;
}
.main_two_right_two_img{
    margin-right: 30px;
   
}
.border_bottom{
    border-bottom: 1px solid #efefef;
}
.two_tr{
    color: #a5a5a5;
    font-size: 16px;
}
.three_tr{
    color: #cccccc;
    font-size: 14px;
}
.three_tr_icon{
    margin-right: 5px;
}
.three_tr_student {
    margin-right: 24px;
}
.three_tr_span{
    font-size: 18px;
    color: #00aaff;
}
</style>