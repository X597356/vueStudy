<template>
    <main class="mian_login">
        <img class="big_img" src="../../assets/img/big_img.jpg" alt="">
        <div class="login_left">
            <div class="login_left_ele" v-for="(item,index) in datas" :key="index" :class="{ele_two:index==double}" @click="dian(index)">
                <div class="login_left_ele_div">
                    <i class="fa fa-2x ele_icon" :class="item.icon"></i>
                    <span class="login_left_ele_text">{{ item.text }}</span>
                </div>
            </div>
        </div>
        <div class="login_right">
            <LoginContentOne v-if="logincontent==1" @contentcg="change"></LoginContentOne>
            <LoginContentTwo v-else-if="logincontent==2" @contentcg="change"></LoginContentTwo>
            <LoginContentThree v-else-if="logincontent==3" v-on:contentcg="change"></LoginContentThree>
        </div>
    </main>
</template>

<script>
import LoginContentOne from './LoginContent/LoginContentOne.vue'
import LoginContentTwo from './LoginContent/LoginContentTwo.vue'
import LoginContentThree from './LoginContent/LoginContentThree.vue'

    export default {
        name:"LoginContent",
        data(){
            return{
                logincontent:1,
                double:1,
                datas:[
                    
                    {
                        icon:"fa-mortar-board",
                        text:"我是学生"
                    },
                    {
                        icon:"fa-user-secret",
                        text:"我是老师"
                    },
                    {
                        icon:"fa-user",
                        text:"我是HR"
                    }
                ]
            }
        },
        methods:{
            dian(index){
                this.double = index
            },
            change(aaa){
                this.logincontent=aaa
            }
        },
        components:{
            LoginContentOne,
            LoginContentTwo,
            LoginContentThree
        }
    }
    
</script>

<style>
.mian_login{
    position: relative;
}
.big_img{
    height: 1070px;
}
.login_left,
.login_right{
    position: absolute;
    top: 180px;
}
.login_left{
    width: 145px;
    height: 610px;
    left: 530px;
    background-color: #202421;
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
    display: flex;
    flex-direction:column;
    overflow: hidden;
}
.login_left_ele{
    flex: 1;
    display: flex;
    align-items: center;
    text-align: center;
    cursor: pointer;
}
.ele_two{
    flex: 2;
    background-color: #adc700;
}
.login_left_ele_div{
    margin: 0 auto;
    color: #fff;
}
.ele_icon{
    margin-bottom: 15px;
}
.login_left_ele_text{
    font-size: 18px;
    display: block;
    color: #fff;
}

/* 右半部分 */
.login_right{
    width: 700px;
    height: 610px;
    left: 675px;
    background-color: #fff;
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px;
    box-shadow: 1px 1px 3px 2px rgba(0, 0, 0, .1);
    padding: 80px 84px 0px;
    box-sizing: border-box;
}

</style>