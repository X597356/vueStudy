<template>
    <div>
        this is LoginContent
    </div>
</template>

<script>
    export default {
        name:"LoginContent"
    }
</script>

<style lang="scss" scoped>

</style>