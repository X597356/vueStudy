<template>
    <div>
        <LoginHeader></LoginHeader>
        <LoginContent></LoginContent>
    </div>
</template>

<script>
import LoginContent from "./LoginContent.vue"
import LoginHeader from "./LoginHeader.vue"
    export default {
        name:"Login",
        components:{
            LoginContent,
            LoginHeader
        },
        
    }
</script>

<style>

</style>