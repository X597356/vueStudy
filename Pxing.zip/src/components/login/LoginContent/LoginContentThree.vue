<template>
    <div>
        <div class="verify_div">通过手机验证码登录</div>
        <form action="">
            <ul>
                <li class="login_list verify_list">
                    <input class="input_login" type="text" placeholder="手机号">
                    <span class="login_list_span">获取验证码</span>
                </li>
                <li class="login_list">
                    <input class="input_login" type="text" placeholder="验证码">
                </li>
            </ul>
        </form>
        <input type="submit" class="verify_div_login " @click="change" value="登录啦">
    </div>
</template>

<script>
    export default {
        name:"LoginContentThree",
        methods:{
            change(){
                this.$router.push({path:'Main'})
            }
        }
    }
</script>

<style lang="less" scoped>
.verify_div_login{
    width: 100%;
    padding: 20px 0;
    text-align: center;
    border-radius: 30px;
    border: 0;
    background-color: #adc700;
    letter-spacing: 0.1em;
    color: #fff;
    cursor: pointer;
    outline: none;
    margin-bottom: 30px;
    font-size: 18px;
    margin-top: 120px;
}
</style>