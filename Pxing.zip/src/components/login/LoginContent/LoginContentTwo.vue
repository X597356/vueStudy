<template>
    <div>
        <div class="verify_div">通过手机号码注册</div>
        <form action="">
            <ul>
                <li class="login_list verify_list">
                    <input class="input_login" type="text" placeholder="手机号">
                    <span class="login_list_span">获取验证码</span>
                </li>
                <li class="login_list">
                    <input class="input_login" type="text" placeholder="验证码">
                </li>
                <li class="login_list">
                    <input class="input_login" type="text" placeholder="密码">
                </li>
            </ul>
        </form>
        <input type="submit" class="verify_div_reg" @click="change" value="提交注册">
    </div>
</template>

<script>
    export default {
        name:"LoginContentTwo.vue",
        methods:{
            change(){
                this.$emit("contentcg",1)
            }
        }
    }
</script>

<style>

.verify_div{
    font-size: 18px;
    text-align: center;
    border-bottom: 5px solid #eeeeee;
    padding-bottom: 20px;
}
.login_list{
    display: flex;
    flex-direction: column;
    height: 100px;
}
.input_login{
    width: 100%;
    border: none;
    border-bottom: 1px solid #eeeeee;
    line-height: 30px;
    font-size: 18px;
    letter-spacing: 0.1em;
    margin-top: auto;
    outline: none;
}
.verify_list{
    position: relative;
}
.login_list_span{
    position: absolute;
    right: 0;
    bottom: 5px;
    font-size: 18px;
    color: #adc700;
    cursor: pointer;
    padding-top: 10px;
}
.verify_div_reg{
    width: 100%;
    padding: 20px 0;
    text-align: center;
    border-radius: 30px;
    border: 0;
    background-color: #adc700;
    letter-spacing: 0.1em;
    color: #fff;
    cursor: pointer;
    outline: none;
    margin-bottom: 30px;
    font-size: 18px;
    margin-top: 50px;
}
</style>