<template>
    <div>
        <div class="login_right_mode">
            <div class="login_right_mode_user" @click="color=true" :class="{right_mode:color==true}">账号登录</div>
            <div class="login_right_mode_wx" @click="color=false" :class="{right_mode:color==false}">微信登录</div>
        </div>
        <!-- 账号密码 -->
        <div v-if="color">
            <form>
                <ul>
                    <li class="login_list">
                        <input class="input_login" type="text" placeholder="手机号">
                    </li>
                    <li class="login_list">
                        <input class="input_login" type="text" placeholder="密码">
                    </li>
                    <li class="login_psd">
                        <label class="login_psd_label" for="" @click="verifyChange">忘记密码？</label>
                    </li>
                </ul>
                <input type="submit" value="登录啦！" class="submit_btn"  @click="tiao()">
            </form>
            <p class="login_right_p">
                还没有账号？
                <span>请</span>
                <span class="login_right_p_reg" @click="changes">注册</span>
            </p>
        </div>
        <!-- 微信登录 -->
        <div v-else>
            <img class="code" src="../../../assets/img/code.jpg" alt="">
            <p class="code_text">微信扫描二维码登录</p>
        </div>
    </div>
</template>

<script>
    export default {
        name:"LoginContentOne",
        data(){
            return{
                color:true,
            }
        },
        methods:{
            tiao(){
                this.$router.push({path:'Main'})
            },
            changes(){
                this.$emit("contentcg", 2)
            },
            verifyChange(){
                this.$emit("contentcg", 3)
            }
        }
    }
</script>

<style lang="less" scoped>
.login_right_mode{
    display: flex;
    margin-bottom: 10px;
}
.login_right_mode_user,
.login_right_mode_wx{
    flex: 1;
    text-align: center;
    color: #737c8e;
    font-size: 18px;
    padding-bottom: 25px;
    box-sizing: border-box;
    border-bottom: 5px solid #eeeeee;
    cursor: pointer;
}
.login_right_mode_user:hover,
.login_right_mode_wx:hover{
    color: #adc700;
}
.right_mode{
    border-bottom: 5px solid #adc700;
    color: #adc700;
}
.login_list{
    display: flex;
    flex-direction: column;
    height: 100px;
}
.input_login{
    width: 100%;
    border: none;
    border-bottom: 1px solid #eeeeee;
    line-height: 30px;
    font-size: 18px;
    letter-spacing: 0.1em;
    margin-top: auto;
    outline: none;
}
.login_psd{
    margin-top: 20px;
    text-align: right;
    letter-spacing: 0.1em;
    margin-bottom: 80px;
}
.login_psd_label{
    cursor: pointer;
    font-size: 18px;
}
.submit_btn{
    width: 100%;
    padding: 20px 0;
    text-align: center;
    border-radius: 30px;
    border: 0;
    background-color: #adc700;
    letter-spacing: 0.1em;
    color: #fff;
    cursor: pointer;
    outline: none;
    margin-bottom: 30px;
    font-size: 18px;
}
.login_right_p{
    color:#c8c8c8;
    text-align: center;
    letter-spacing: 0.1em;
    font-size: 18px;
}
.login_right_p_reg{
    margin-left: 10px;
    color: #adc700;
    cursor: pointer;
}
.code{
    width: 330px;
    height: 330px;
    margin: 40px auto;
    display: block;
}
.code_text{
    text-align: center;
    letter-spacing: 0.1em;
}
</style>