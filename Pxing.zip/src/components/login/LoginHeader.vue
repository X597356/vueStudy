<template>
    <nav>
        <div class="nav">
            <img src="../../assets/img/logo_two.jpg" alt="">
            <div class="nav_div">
                <span class="nav_div_span">登录</span>
                丨
                <span class="nav_div_span">注册</span>
            </div>
        </div>
        
    </nav>
</template>

<script>
    export default {
        name:"LoginHeader",
        methods:{
            // change(){
            //     this.$emit("contentcg",1)
            // },
            // changes(){
            //     this.$emit("contentcg",2)
            // }
        }
    }
</script>

<style>
nav{
    background-color: #fff;
    box-shadow: 0 1px 5px rgba(0, 0, 0, .1);
}
.nav{
    width: 1555px;
    margin: 0 auto;
    display: flex;
    align-items: center;
}
.nav_div{
    margin-left: auto;
    color: #a1a1a1;
}
.nav_div_span{
    cursor: pointer;
}
.nav_div_span:hover{
    color: #00aaff;
}
</style>