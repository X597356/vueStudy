import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../components/login/Login.vue'
import Main from '../components/Main.vue'
import MainOne from '../components/mainone/MainOne.vue'
import MainTwo from '../components/maintwo/MainTwo.vue'
import MainThree from '../components/mainthree/MainThree.vue'
import MainFour from '../components/mainfour/MainFour.vue'
import MainFive from '../components/mainfive/MainFive.vue'
import MainFourRight from '../components/mainfour/MainFourRight.vue'
import MainFourRightTwo from '../components/mainfour/MainFourRightTwo.vue'
import MainTwoRightBox from '../components/maintwo/MainTwoRightBoxOne/MainTwoRightBox.vue'
import MainTwoRightBoxTwo from '../components/maintwo/MainTwoRightBoxTwo/MainTwoRightBoxTwo.vue'
import MainTwoRightBoxThree from '../components/maintwo/MainTwoRightBoxThree/MainTwoRightBoxThree.vue'
import MainThreeRightOneBox from '../components/mainthree/MainThreeRightOneBox.vue'
import MainThreeRightTwoBox from '../components/mainthree/MainThreeRightTwoBox.vue'
import MainThreeRightThreeBox from '../components/mainthree/MainThreeRightThreeBox.vue'


Vue.use(VueRouter)

const routes = [
    {
        path:'',
        component:Login
    },
    {
        path:'/Login',
        component:Login
    },
    {
        path:'/Main',
        component:Main,
        children:[
            {
                path: '/',
                component:MainOne
            },
            {
                path: '/one',
                component:MainOne
            },
            {
                path: '/two',
                component:MainTwo,
                children:[
                    {
                        path:'/',
                        component:MainTwoRightBox
                    },
                    {
                        path:'/twofirst',
                        component:MainTwoRightBox
                    },
                    {
                        path:'/twosecond',
                        component:MainTwoRightBoxTwo
                    },
                    {
                        path:'/twolast',
                        component:MainTwoRightBoxThree
                    },
        
                ]
            },
            {
                path: '/three',
                component:MainThree,
                children:[
                    {
                        path:'/',
                        component:MainThreeRightOneBox
                    },
                    {
                        path:'/threefirst',
                        component:MainThreeRightOneBox
                    },
                    {
                        path:'/threesecond',
                        component:MainThreeRightTwoBox
                    },
                    {
                        path:'/threelast',
                        component:MainThreeRightThreeBox
                    },
                ]
            },
            {
                path: '/four',
                component:MainFour,
                children:[
                    {
                        path:'/',
                        component:MainFourRight
                    },
                    {
                        path:'/first',
                        component:MainFourRight
                    },
                    {
                        path:'/last',
                        component:MainFourRightTwo
                    }
                ]
            },
            {
                path: '/five',
                component:MainFive
            },
        ]
    }
    
]

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes
})
 
export default router
