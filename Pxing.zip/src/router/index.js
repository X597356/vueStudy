import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../App.vue'
import MainOne from '../components/mainone/MainOne.vue'
import MainTwo from '../components/maintwo/MainTwo.vue'
import MainThree from '../components/mainthree/MainThree.vue'
import MainFour from '../components/mainfour/MainFour.vue'
import MainFive from '../components/mainfive/MainFive.vue'
import MainFourRight from '../components/mainfour/MainFourRight.vue'
import MainFourRightTwo from '../components/mainfour/MainFourRightTwo.vue'


Vue.use(VueRouter)

const routes = [
    {
        path:'',
        component:MainOne
    },
    {
        path: '/',
        component:MainOne
    },
    {
        path: '/one',
        component:MainOne
    },
    {
        path: '/two',
        component:MainTwo
    },
    {
        path: '/three',
        component:MainThree
    },
    {
        path: '/four',
        component:MainFour,
        children:[
            {
                path:'/first',
                component:MainFourRight
            },
            {
                path:'/last',
                component:MainFourRightTwo
            }
        ]
    },
    {
        path: '/five',
        component:MainFive
    },
]

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes
})
 
export default router
